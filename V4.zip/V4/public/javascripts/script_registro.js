// Evento para redirigir al login (enlace "Iniciar Sesión")
document.getElementById('login-link')?.addEventListener('click', function(event) {
    event.preventDefault();
    window.location.href = '/login'; // Ajusta según tu ruta real
});

// Evento para recuperar contraseña (pendiente de implementar)
document.getElementById('forgot-password-link')?.addEventListener('click', function(event) {
    event.preventDefault();
    alert('Funcionalidad de recuperar contraseña aún no implementada.');
});

// Validación básica del formulario de registro
const registroForm = document.getElementById('registro-form');
if (registroForm) {
    registroForm.addEventListener('submit', function(event) {
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();

        if (!username || !password) {
            event.preventDefault();
            alert('Por favor, completa todos los campos.');
        }
    });
}

