package controllers;

import play.*;
import play.mvc.*;
import models.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

public class Application extends Controller {

    // Página principal
    public static void EnviaPaginaPrincipal() {
        renderTemplate("Application/index.html");
    }

    // Página de registro
    public static void registro() {
        renderTemplate("Application/Registro.html");
    }

    // Procesa el formulario de registro
    public static void register(String username, String password) {
        Usuario existingUser = Usuario.find("byUsername", username).first();
        if (existingUser != null) {
            flash.error("El usuario ya está registrado.");
            registro();  // Vuelve al formulario
        }

        // Crea y guarda el nuevo usuario sin el parámetro 'age'
        new Usuario(username, password).save();
        flash.success("Usuario registrado exitosamente.");
        EnviaPaginaPrincipal();  // Redirige a la página principal
    }

    // Página de inicio de sesión
    public static void login() {
        renderTemplate("Application/login.html"); // Asegúrate de tener esta vista
    }

    // Procesa el inicio de sesión
    public static void processLogin(String username, String password) {
        Usuario user = Usuario.find("byUsernameAndPassword", username, password).first();
        if (user != null) {
            flash.success("Welcome, " + user.username + "!");
            EnviaPaginaPrincipal();  // Redirige a la página principal después del login
        } else {
            flash.error("Credenciales incorrectas.");
            login();  // Vuelve al formulario de login
        }
    }

    // Página de soluciones (plans)
    public static void plans() {
        renderTemplate("Application/plans.html");
    }

    // Página About
    public static void about() {
        renderTemplate("Application/about.html");
    }

    // Carga los puertos desde el CSV
    public static void cargarPuertos() {
        utils.CargarCSV.cargarPuertosDesdeCSV();
        flash.success("Puertos cargados en la base de datos.");
        EnviaPaginaPrincipal(); // Redirige a la página principal
    }

    public static void obtenerPuertos() {
        List<Puerto> puertos = Puerto.findAll();
        List<Map<String, Object>> resultado = new ArrayList<>();

        for (Puerto p : puertos) {
            Map<String, Object> puertoMap = new HashMap<>();
            puertoMap.put("id", p.id);
            puertoMap.put("nombre", p.nombre);
            puertoMap.put("latitud", p.latitud);
            puertoMap.put("longitud", p.longitud);
            resultado.add(puertoMap);
        }

        renderJSON(resultado);
    }

    // Cargar las mediciones desde el CSV
    public static void cargarMediciones() {
        utils.CargarMediciones.cargarMedicionesDesdeCSV();
        flash.success("Mediciones cargadas correctamente desde el CSV.");
        Application.EnviaPaginaPrincipal(); // Redirige a la página principal
    }

    public static void obtenerMediciones() {
        List<Medicion> mediciones = Medicion.findAll();
        List<Map<String, Object>> datos = new ArrayList<>();

        for (Medicion m : mediciones) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", m.id);
            item.put("fecha", m.fecha);
            item.put("so4", m.so4);
            item.put("co2", m.co2);
            item.put("no2", m.no2);
            item.put("ch4", m.ch4);
            item.put("puertoNombre", m.puerto != null ? m.puerto.nombre : "Desconocido");
            datos.add(item);
        }

        renderJSON(datos);
    }





}



