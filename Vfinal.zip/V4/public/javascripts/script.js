document.addEventListener('DOMContentLoaded', function () {

console.log("NIMS Landing Page Ready");

// Mediterranean Sea boundaries
const MED_BOUNDS = {
    latMin: 30,
    latMax: 45,
    lngMin: -5,
    lngMax: 36
};

const map = L.map('map', {
    center: [40, 15],
    zoom: 4.5,
    interactive: false,
    zoomControl: false,
    dragging: false,
    scrollWheelZoom: false,
    doubleClickZoom: false,
    boxZoom: false,
    keyboard: false
});
let landPolygons = null;
let vessels = [];
let vesselMarkers = [];

// Add OpenStreetMap base layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Function to check if a point is on land
function isOverLand(lat, lng) {
    if (!landPolygons || !landPolygons.features) {
        return false;
    }
    const pt = turf.point([lng, lat]);
    for (const feature of landPolygons.features) {
        if (turf.booleanPointInPolygon(pt, feature)) {
            return true; // Point is on land
        }
    }
    return false; // Point is in the water
}

// Function to generate a valid starting position (not on land)
function generateValidPosition() {
    let lat, lng;
    let attempts = 0;
    const maxAttempts = 100; // Prevent infinite loops

    do {
        lat = MED_BOUNDS.latMin + Math.random() * (MED_BOUNDS.latMax - MED_BOUNDS.latMin);
        lng = MED_BOUNDS.lngMin + Math.random() * (MED_BOUNDS.lngMax - MED_BOUNDS.lngMin);
        attempts++;
        if (attempts >= maxAttempts) {
            console.warn("Max attempts reached for valid position, using fallback.");
            return { lat: 37, lng: 15 };
        }
    } while (isOverLand(lat, lng));

    return { lat, lng };
}

// Initialize vessels with positions, headings, and markers
function initializeVessels(count) {
    vessels = [];
    vesselMarkers.forEach(marker => map.removeLayer(marker));
    vesselMarkers = [];

    for (let i = 0; i < count; i++) {
        const pos = generateValidPosition();
        const heading = Math.random() * 360;
        const marker = L.circleMarker([pos.lat, pos.lng], {
            radius: 1,
            fillColor: 'red',
            color: 'red',
            fillOpacity: 0.7
        }).addTo(map);

        vessels.push({
            lat: pos.lat,
            lng: pos.lng,
            heading: heading,
            marker: marker
        });
        vesselMarkers.push(marker);
    }
    console.log(`Initialized ${vessels.length} vessels.`);
}

// --- Animation Logic ---

const ANIMATION_INTERVAL = 100;
const VESSEL_SPEED = 0.05;

function animateVessels() {
    vessels.forEach(v => {
        // Calculate potential next position based on current heading and speed
        const radHeading = v.heading * (Math.PI / 180); // Convert heading to radians
        let nextLat = v.lat + VESSEL_SPEED * Math.cos(radHeading);
        let nextLng = v.lng + VESSEL_SPEED * Math.sin(radHeading);

        // --- Collision Detection ---
        if (isOverLand(nextLat, nextLng)) {
            // Collision detected! Change course.
            v.heading = (v.heading + 180 + (Math.random() * 90 - 45)) % 360; // Turn around +/- 45 degrees
            console.log(`Vessel at [${v.lat.toFixed(2)}, ${v.lng.toFixed(2)}] hit land, new heading: ${v.heading.toFixed(1)}`);

            // Recalculate next position with the new heading to avoid getting stuck
            const newRadHeading = v.heading * (Math.PI / 180);
            nextLat = v.lat + VESSEL_SPEED * Math.cos(newRadHeading);
            nextLng = v.lng + VESSEL_SPEED * Math.sin(newRadHeading);

            if (isOverLand(nextLat, nextLng)) {
                v.heading = Math.random() * 360;
                return;
            }
        }

        // --- Boundary Check (Mediterranean Sea) ---
        if (nextLat < MED_BOUNDS.latMin || nextLat > MED_BOUNDS.latMax || nextLng < MED_BOUNDS.lngMin || nextLng > MED_BOUNDS.lngMax) {
            // Hit the boundary, turn around
            v.heading = (v.heading + 180) % 360;
            console.log(`Vessel at [${v.lat.toFixed(2)}, ${v.lng.toFixed(2)}] hit boundary, new heading: ${v.heading.toFixed(1)}`);
            // Recalculate next position
            const newRadHeading = v.heading * (Math.PI / 180);
            nextLat = v.lat + VESSEL_SPEED * Math.cos(newRadHeading);
            nextLng = v.lng + VESSEL_SPEED * Math.sin(newRadHeading);

            // If still out of bounds after turning (e.g., corner case), stop it for this frame
            if (nextLat < MED_BOUNDS.latMin || nextLat > MED_BOUNDS.latMax || nextLng < MED_BOUNDS.lngMin || nextLng > MED_BOUNDS.lngMax) {
                return;
            }
        }
        v.lat = nextLat;
        v.lng = nextLng;

        v.marker.setLatLng([v.lat, v.lng]);
    });
    console.log("Vessels animated.");
}

// --- Atmosphere Map ---
const atmosphereMap = L.map('atmosphere-map', {
    center: [40, 15],
    zoom: 4.5,
    interactive: false,
    zoomControl: false,
    dragging: false,
    scrollWheelZoom: false,
    doubleClickZoom: false,
    boxZoom: false,
    keyboard: false
});

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(atmosphereMap);

let heatmapLayer;
let heatmapLayer2;
let heatmapLayer3;

function generateAtmosphereData(points = 1000, intensity = 0.5) {
    const data = [];
    for (let i = 0; i < points; i++) {
        const lat = Math.random() * 70;
        const lng = -20 + Math.random() * 80;
        const value = Math.random() * intensity;
        data.push([lat, lng, value]);
    }
    return data;
}

function initializeAtmosphere() {
    const initialAtmosphereData = generateAtmosphereData(10000, 0.5);
    const initialAtmosphereData2 = generateAtmosphereData(8000, 0.6);
    const initialAtmosphereData3 = generateAtmosphereData(6000, 0.7);

    heatmapLayer = L.heatLayer(initialAtmosphereData, {
        radius: 40,
        blur: 25,
        gradient: {
            0.0: 'rgba(0, 0, 0, 0)',
            0.1: 'rgba(0, 0, 255, 0.4)',
            0.3: 'rgba(0, 255, 255, 0.6)',
            0.5: 'rgba(0, 255, 0, 0.7)',
            0.7: 'rgba(255, 255, 0, 0.8)',
            0.9: 'rgba(255, 128, 0, 0.9)',
            1.0: 'rgba(255, 0, 0, 1.0)'
        }
    }).addTo(atmosphereMap);

    heatmapLayer2 = L.heatLayer(initialAtmosphereData2, {
        radius: 30, 
        blur: 20, 
        gradient: {
            0.0: 'rgba(0, 0, 0, 0)',
            0.1: 'rgba(0, 255, 0, 0.3)',  
            0.3: 'rgba(0, 255, 100, 0.5)',
            0.5: 'rgba(200, 255, 0, 0.6)',
            0.7: 'rgba(255, 200, 0, 0.7)',
            0.9: 'rgba(255, 100, 0, 0.8)',
            1.0: 'rgba(255, 0, 100, 0.9)'
        }
    }).addTo(atmosphereMap);

    heatmapLayer3 = L.heatLayer(initialAtmosphereData3, {
        radius: 20,
        blur: 15,
        gradient: {
            0.0: 'rgba(0, 0, 0, 0)',
            0.1: 'rgba(255, 0, 255, 0.2)',
            0.3: 'rgba(255, 100, 255, 0.4)',
            0.5: 'rgba(200, 100, 255, 0.5)',
            0.7: 'rgba(200, 200, 255, 0.6)',
            0.9: 'rgba(100, 200, 255, 0.7)',
            1.0: 'rgba(0, 0, 255, 0.8)'
        }
    }).addTo(atmosphereMap);
}

function animateAtmosphereHeatmap() {
    const newData = generateAtmosphereData(10000, 0.5);
    const newData2 = generateAtmosphereData(8000, 0.6);
    const newData3 = generateAtmosphereData(6000, 0.7);

    // Clear and re-add the layers (more robust update)
    atmosphereMap.removeLayer(heatmapLayer);
    atmosphereMap.removeLayer(heatmapLayer2);
    atmosphereMap.removeLayer(heatmapLayer3);

    heatmapLayer = L.heatLayer(newData, {
        radius: 40,
        blur: 25,
        gradient: {
            0.0: 'rgba(0, 0, 0, 0)',
            0.2: 'rgba(0, 0, 255, 0.4)',
            0.4: 'rgba(0, 255, 255, 0.6)',
            0.6: 'rgba(0, 255, 0, 0.7)',
            0.7: 'rgba(255, 255, 0, 0.8)',
            0.8: 'rgba(255, 128, 0, 0.9)',
            1.0: 'rgba(255, 0, 0, 1.0)'
        }
    }).addTo(atmosphereMap);

    heatmapLayer2 = L.heatLayer(newData2, {
        radius: 30,
        blur: 20,
        gradient: {
            0.0: 'rgba(0, 0, 0, 0)',
            0.2: 'rgba(0, 255, 0, 0.3)',
            0.4: 'rgba(0, 255, 100, 0.5)',
            0.6: 'rgba(200, 255, 0, 0.6)',
            0.7: 'rgba(255, 200, 0, 0.7)',
            0.8: 'rgba(255, 100, 0, 0.8)',
            1.0: 'rgba(255, 0, 100, 0.9)'
        }
    }).addTo(atmosphereMap);

    heatmapLayer3 = L.heatLayer(newData3, {
        radius: 20,
        blur: 15,
        gradient: {
            0.0: 'rgba(0, 0, 0, 0)',
            0.2: 'rgba(255, 0, 255, 0.2)',
            0.4: 'rgba(255, 100, 255, 0.4)',
            0.6: 'rgba(200, 100, 255, 0.5)',
            0.7: 'rgba(200, 200, 255, 0.6)',
            0.8: 'rgba(100, 200, 255, 0.7)',
            1.0: 'rgba(0, 0, 255, 0.8)'
        }
    }).addTo(atmosphereMap);
}

// --- Initialization ---

// Fetch land data first
fetch('https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_land.geojson')
    .then(res => {
        if (!res.ok) {
            throw new Error(`HTTP error fetching land data! status: ${res.status}`);
        }
        return res.json();
    })
    .then(data => {
        console.log("Land data loaded successfully.");
        landPolygons = data;

        initializeVessels(200);

        setInterval(animateVessels, ANIMATION_INTERVAL);
        console.log("Animation started.");

        initializeAtmosphere();
        setInterval(animateAtmosphereHeatmap, 2000);
    })
    .catch(error => {
        console.error('Error loading or processing land data:', error);
    });


// --- Add Mediterranean Ports ---
let ports = [];

fetch('/api/puertos')
  .then(response => response.json())
  .then(data => {
    ports = data.map(puerto => ({
      name: puerto.nombre,
      lat: puerto.latitud,
      lng: puerto.longitud
    }));

    // Aquí dentro colocamos el forEach
    ports.forEach(port => {
      L.circleMarker([port.lat, port.lng], {
        radius: 7,
        color: '#002855',
        fillColor: '#4db8ff',
        fillOpacity: 0.9,
        weight: 2
      }).addTo(map).bindPopup(`<b>${port.name}</b><br>Commercial Port`);
    });

    console.log(ports);
  })
  .catch(error => console.error('Error al obtener puertos:', error));


// --- Cargar mediciones desde la API ---
let pollutionData = [];

// Obtiene los datos de la API
fetch('/api/mediciones')
  .then(response => response.json())
  .then(data => {
    // Transformar la estructura de datos
    pollutionData = data.map(item => ({
      Port: item.puertoNombre,
      Date: new Date(item.fecha).toISOString().split('T')[0], // Formato yyyy-MM-dd
      SO4: item.so4,
      CO2: item.co2,
      NO2: item.no2,
      CH4: item.ch4
    }));

    // Rellenar el select con puertos únicos
    const ports = [...new Set(pollutionData.map(d => d.Port))];
    ports.forEach(port => {
      const option = document.createElement('option');
      option.value = port;
      option.textContent = port;
      portSelect.appendChild(option);
    });

    // Seleccionar el primer puerto automáticamente
    if (ports.length > 0) {
      portSelect.value = ports[0];  // Establecer el primer puerto como seleccionado
      updatePollutionChart();      // Llamar a la función para generar la gráfica
    }

  })
  .catch(error => console.error('Error al obtener mediciones:', error));


// --- Pollution Chart Section ---

const portSelect = document.getElementById('port-select');
const pollutionChartCanvas = document.getElementById('pollutionChart');

let pollutionChart;

// Función para actualizar el gráfico según el puerto seleccionado
function updatePollutionChart() {
  const selectedPortName = portSelect.value;

  if (!selectedPortName) {
    if (pollutionChart) {
      pollutionChart.destroy();
      pollutionChart = null;
    }
    return;
  }

  // Filtrar los datos por puerto
  const dataForSelectedPort = pollutionData.filter(d => d.Port === selectedPortName);

  // Ordenar por fecha
  dataForSelectedPort.sort((a, b) => new Date(a.Date) - new Date(b.Date));

  const labels = dataForSelectedPort.map(d => d.Date);
  const so4Values = dataForSelectedPort.map(d => d.SO4);
  const co2Values = dataForSelectedPort.map(d => d.CO2);
  const no2Values = dataForSelectedPort.map(d => d.NO2);
  const ch4Values = dataForSelectedPort.map(d => d.CH4);

  const datasets = [
    {
      label: 'SO4',
      data: so4Values,
      borderColor: 'rgba(75, 192, 192, 1)',
      backgroundColor: 'rgba(75, 192, 192, 0.2)',
      fill: false,
      tension: 0.1
    },
    {
      label: 'CO2',
      data: co2Values,
      borderColor: 'rgba(255, 99, 132, 1)',
      backgroundColor: 'rgba(255, 99, 132, 0.2)',
      fill: false,
      tension: 0.1
    },
    {
      label: 'NO2',
      data: no2Values,
      borderColor: 'rgba(54, 162, 235, 1)',
      backgroundColor: 'rgba(54, 162, 235, 0.2)',
      fill: false,
      tension: 0.1
    },
    {
      label: 'CH4',
      data: ch4Values,
      borderColor: 'rgba(255, 206, 86, 1)',
      backgroundColor: 'rgba(255, 206, 86, 0.2)',
      fill: false,
      tension: 0.1
    }
  ];

  if (pollutionChart) {
    pollutionChart.data.labels = labels;
    pollutionChart.data.datasets = datasets;
    pollutionChart.options.plugins.title.text = `Pollutant Evolution for ${selectedPortName}`;
    pollutionChart.update();
  } else {
    pollutionChart = new Chart(pollutionChartCanvas, {
      type: 'line',
      data: {
        labels: labels,
        datasets: datasets
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            type: 'category',
            title: {
              display: true,
              text: 'Date'
            }
          },
          y: {
            title: {
              display: true,
              text: 'Concentration (ppm)'
            },
            beginAtZero: true
          }
        },
        plugins: {
          tooltip: {
            mode: 'index',
            intersect: false
          },
          title: {
            display: true,
            text: `Pollutant Evolution for ${selectedPortName}`
          }
        }
      }
    });
  }
}


// Add event listener to the select dropdown
portSelect.addEventListener('change', updatePollutionChart);

// Optional: Populate port select only with ports available in the simulated data
const portsInSimulatedData = [...new Set(pollutionData.map(row => row.Port))];
function populatePortSelectFromSimulatedData() {
    portsInSimulatedData.forEach(portName => {
        const option = document.createElement('option');
        option.value = portName;
        option.textContent = portName;
        portSelect.appendChild(option);
    });
}


// Call this function instead of populatePortSelect() if you only want ports from the CSV
populatePortSelectFromSimulatedData();

// Trigger the initial chart display after the ports are loaded
if (portsInSimulatedData.length > 0) {
    updatePollutionChart();
}





});