package models;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import play.db.jpa.Model;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Puerto extends Model {
    public String nombre;
    public float latitud;
    public float longitud;

    @OneToMany(mappedBy = "puerto")
    public List<Ubicacion> ubicaciones = new ArrayList<>();

    @OneToMany(mappedBy = "puerto")
    public List<Medicion> mediciones = new ArrayList<>();

    public Puerto() {
    }

    public Puerto(String nombre, float latitud, float longitud) {
        this.nombre = nombre;
        this.latitud = latitud;
        this.longitud = longitud;
    }
}

