// Evento para redirigir al registro (enlace "¿No tienes cuenta? Regístrate")
document.getElementById('registro-link')?.addEventListener('click', function(event) {
    event.preventDefault();
    window.location.href = '/registro'; // Ajusta según la ruta real de tu app
});

// Evento para recuperar contraseña (pendiente de implementar)
document.getElementById('forgot-password-link')?.addEventListener('click', function(event) {
    event.preventDefault();
    alert('Funcionalidad de recuperar contraseña aún no implementada.');
});

// Validación básica del formulario de login
const loginForm = document.getElementById('login-form');
if (loginForm) {
    loginForm.addEventListener('submit', function(event) {
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();

        if (!username || !password) {
            event.preventDefault();
            alert('Por favor, introduce tu nombre de usuario y contraseña.');
        }
    });
}
