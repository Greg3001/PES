package models;

import javax.persistence.*;
import play.db.jpa.Model;

@Entity
public class Usuario extends Model {

    @Column(unique = true, nullable = false)
    public String username;

    @Column(nullable = false)
    public String password;


    // Constructor vacío necesario para JPA
    public Usuario() {
    }

    public Usuario(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Opcional: puedes agregar métodos getter y setter si planeas usarlos desde formularios.
}
