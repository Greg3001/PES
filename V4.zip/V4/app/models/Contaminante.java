package models;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import play.db.jpa.Model;
import java.util.Date;

@Entity
public class Medicion extends Model {
    @ManyToOne
    public Puerto puerto;

    public Date fecha;

    public Float so4;
    public Float co2;
    public Float no2;
    public Float ch4;

    public Medicion() {
    }

    public Medicion(Puerto puerto, Date fecha, Float so4, Float co2, Float no2, Float ch4) {
        this.puerto = puerto;
        this.fecha = fecha;
        this.so4 = so4;
        this.co2 = co2;
        this.no2 = no2;
        this.ch4 = ch4;
    }
}
