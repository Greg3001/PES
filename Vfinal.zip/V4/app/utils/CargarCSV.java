package utils;

import models.Puerto;
import play.db.jpa.JPA;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CargarCSV {

    public static void cargarPuertosDesdeCSV() {
        try {
            // Abre el archivo CSV desde la carpeta conf (ajusta si lo colocaste en otra parte)
            InputStream is = CargarCSV.class.getClassLoader().getResourceAsStream("ports_data.csv");
            if (is == null) {
                System.out.println("No se encontró el archivo CSV.");
                return;
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String linea;

            // Leer encabezado
            linea = reader.readLine(); // Saltar la primera línea (encabezado)

            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    String nombre = partes[0].trim();
                    float latitud = Float.parseFloat(partes[1].trim());
                    float longitud = Float.parseFloat(partes[2].trim());

                    // Guardar en la base de datos
                    Puerto puerto = new Puerto(nombre, latitud, longitud);
                    puerto.save(); // Método de Play Framework para guardar el modelo
                }
            }

            reader.close();
            System.out.println("Carga de puertos finalizada correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
