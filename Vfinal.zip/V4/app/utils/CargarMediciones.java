package utils;

import models.Puerto;
import models.Medicion;
import play.db.jpa.JPA;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CargarMediciones {

    public static void cargarMedicionesDesdeCSV() {
        try {
            InputStream is = CargarMediciones.class.getClassLoader().getResourceAsStream("mediciones.csv");
            if (is == null) {
                System.out.println("No se encontró el archivo mediciones.csv");
                return;
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String linea;

            // Leer encabezado
            linea = reader.readLine(); // Saltar la primera línea

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 6) {
                    String portName = partes[0].trim();
                    Date fecha = sdf.parse(partes[1].trim());
                    Float so4 = Float.parseFloat(partes[2].trim());
                    Float co2 = Float.parseFloat(partes[3].trim());
                    Float no2 = Float.parseFloat(partes[4].trim());
                    Float ch4 = Float.parseFloat(partes[5].trim());

                    // Buscar puerto por nombre
                    Puerto puerto = Puerto.find("byNombre", portName).first();
                    if (puerto == null) {
                        System.out.println("Puerto no encontrado: " + portName);
                        continue; // Saltar esta línea si el puerto no existe
                    }

                    // Crear y guardar la medición
                    Medicion medicion = new Medicion(puerto, fecha, so4, co2, no2, ch4);
                    medicion.save();
                }
            }

            reader.close();
            System.out.println("Carga de mediciones finalizada correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
