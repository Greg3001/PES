import play.*;
import play.jobs.*;
import utils.CargarCSV;
import utils.CargarMediciones;

@OnApplicationStart
public class Bootstrap extends Job {
    public void doJob() {
        // Cargar puertos si la base de datos está vacía
        if (models.Puerto.count() == 0) {
            CargarCSV.cargarPuertosDesdeCSV();
        }

        // Cargar mediciones si la base de datos está vacía
        if (models.Medicion.count() == 0) {
            CargarMediciones.cargarMedicionesDesdeCSV();
        }
    }
}
