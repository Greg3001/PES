package controllers;

import play.*;
import play.mvc.*;
import models.*;

public class Application extends Controller {

    // Página principal
    public static void EnviaPaginaPrincipal() {
        renderTemplate("Application/index.html");
    }

    // Página de registro
    public static void registro() {
        renderTemplate("Application/Registro.html");
    }

    // Procesa el formulario de registro
    public static void register(String username, String password) {
        Usuario existingUser = Usuario.find("byUsername", username).first();
        if (existingUser != null) {
            flash.error("El usuario ya está registrado.");
            registro();  // Vuelve al formulario
        }

        // Crea y guarda el nuevo usuario sin el parámetro 'age'
        new Usuario(username, password).save();
        flash.success("Usuario registrado exitosamente.");
        EnviaPaginaPrincipal();  // Redirige a la página principal
    }

    // Página de inicio de sesión
    public static void login() {
        renderTemplate("Application/login.html"); // Asegúrate de tener esta vista
    }

    // Procesa el inicio de sesión
    public static void processLogin(String username, String password) {
        Usuario user = Usuario.find("byUsernameAndPassword", username, password).first();
        if (user != null) {
            flash.success("Bienvenido, " + user.username + "!");
            EnviaPaginaPrincipal();  // Redirige a la página principal después del login
        } else {
            flash.error("Credenciales incorrectas.");
            login();  // Vuelve al formulario de login
        }
    }

    // Página de soluciones (plans)
    public static void plans() {
        renderTemplate("Application/plans.html");
    }

    // Página About
    public static void about() {
        renderTemplate("Application/about.html");
    }

    // Carga los puertos desde el CSV
    public static void cargarPuertos() {
        utils.CargarCSV.cargarPuertosDesdeCSV();
        flash.success("Puertos cargados en la base de datos.");
        EnviaPaginaPrincipal(); // Redirige a la página principal
    }

    // Devuelve todos los puertos en JSON
    public static void obtenerPuertos() {
        List<Puerto> puertos = Puerto.findAll();
        renderJSON(puertos);
    }

    // Cargar las mediciones desde el CSV
    public static void cargarMediciones() {
        utils.CargarMediciones.cargarMedicionesDesdeCSV();
        flash.success("Mediciones cargadas correctamente desde el CSV.");
        Application.EnviaPaginaPrincipal(); // Redirige a la página principal
    }

    // Devolver todas las mediciones en formato JSON
    public static void obtenerMediciones() {
        List<Medicion> mediciones = Medicion.findAll();
        renderJSON(mediciones);
    }



}



